from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
import numpy as np, cv2
from scipy.spatial.transform import Rotation as Rot


@dataclass
class Imu:
    t_ns: np.ndarray      # (N,) int64
    acc: np.ndarray       # (N,3) specific force incl. gravity, m/s^2
    gyr: np.ndarray       # (N,3) rad/s


@dataclass
class Sequence:
    name: str
    frame_ts: np.ndarray              # (F,) int64 ns
    frame_paths: list
    imu: Imu
    gt_t_ns: np.ndarray               # (G,) int64 ns
    gt_p: np.ndarray                  # (G,3) metres, local world frame
    gt_q: np.ndarray | None = None    # (G,4) xyzw, or None if not available
    K: np.ndarray | None = None
    dist: np.ndarray | None = None
    meta: dict = field(default_factory=dict)

    def read_frame(self, i, color=False):
        return cv2.imread(str(self.frame_paths[i]), cv2.IMREAD_COLOR if color else cv2.IMREAD_GRAYSCALE)

    def imu_between(self, t0, t1) -> Imu:
        """IMU samples with t0 < t <= t1."""
        a, b = np.searchsorted(self.imu.t_ns, [t0, t1], side="right")
        return Imu(self.imu.t_ns[a:b], self.imu.acc[a:b], self.imu.gyr[a:b])

    def replay(self, with_images=True):
        """Yield ('imu', t, (acc, gyr)) and ('frame', t, (i, img)) in time order.
        This is the interface a live V4L2/IMU source will implement later."""
        n_i = len(self.imu.t_ns)
        t = np.concatenate([self.imu.t_ns, self.frame_ts])
        kind = np.concatenate([np.zeros(n_i, int), np.ones(len(self.frame_ts), int)])
        for o in np.lexsort((kind, t)):          # sort by time, IMU before frame on ties
            if o < n_i:
                yield "imu", int(t[o]), (self.imu.acc[o], self.imu.gyr[o])
            else:
                i = o - n_i
                yield "frame", int(t[o]), (i, self.read_frame(i) if with_images else None)


# ---------------------------------------------------------------- KITTI
def _read_ts(p):
    s = [l.strip().replace(" ", "T") for l in open(p) if l.strip()]
    return np.array(s, dtype="datetime64[ns]").astype(np.int64)


def repair_timestamps(t_ns, tol_s=0.015, win=15, merge_gap=20):
    """Fix glitched timestamps (jumps/backwards steps). The sample index is the trusted clock:
    flag samples far from the local trend, then re-time each glitch cluster by linear
    interpolation between good anchors on either side."""
    n = len(t_ns); idx = np.arange(n)
    t = (t_ns - t_ns[0]) * 1e-9
    slope, icpt = np.polyfit(idx, t, 1)
    resid = t - (slope * idx + icpt)
    med = np.array([np.median(resid[max(0, i - win):i + win + 1]) for i in idx])
    bad = np.where(np.abs(resid - med) > tol_s)[0]
    t_fix, clusters = t.copy(), []
    if len(bad):
        for g in np.split(bad, np.where(np.diff(bad) > merge_gap)[0] + 1):
            lo, hi = max(g[0] - 1, 0), min(g[-1] + 1, n - 1)
            t_fix[lo:hi + 1] = np.interp(idx[lo:hi + 1], [lo, hi], [t[lo], t[hi]])
            clusters.append((int(lo), int(hi)))
    out = t_ns[0] + np.round(t_fix * 1e9).astype(np.int64)
    if not (np.diff(out) > 0).all():
        print("WARNING: timestamps still not strictly increasing after repair")
    return out, clusters


def load_kitti(drive_dir) -> Sequence:
    d = Path(drive_dir)
    cam_ts = _read_ts(d / "image_02" / "timestamps.txt")
    imu_raw = _read_ts(d / "oxts" / "timestamps.txt")
    imu_ts, clusters = repair_timestamps(imu_raw)
    oxts = np.stack([np.loadtxt(d / "oxts" / "data" / f"{i:010d}.txt") for i in range(len(imu_ts))])
    lat, lon, alt, roll, pitch, yaw = oxts[:, :6].T
    # ground truth: Mercator position (KITTI devkit convention), ENU, first sample = origin
    sc, R_E = np.cos(np.deg2rad(lat[0])), 6378137.0
    mx = sc * np.deg2rad(lon) * R_E
    my = sc * R_E * np.log(np.tan(np.pi / 4 + np.deg2rad(lat) / 2))
    gt_p = np.c_[mx - mx[0], my - my[0], alt - alt[0]]
    gt_q = Rot.from_euler("ZYX", np.c_[yaw, pitch, roll]).as_quat()   # Rz(yaw) Ry(pitch) Rx(roll)
    paths = sorted((d / "image_02" / "data").glob("*.png"))
    return Sequence(
        name=d.name, frame_ts=cam_ts, frame_paths=paths,
        imu=Imu(imu_ts, oxts[:, 11:14].copy(), oxts[:, 17:20].copy()),
        gt_t_ns=imu_ts, gt_p=gt_p, gt_q=gt_q,
        meta=dict(dataset="kitti", imu_hz=100, cam_hz=10, repaired_clusters=clusters,
                  note="OXTS accel/gyro come from a GPS/INS unit (higher grade than a consumer IMU)"))


# ---------------------------------------------------------------- EuRoC (cleaned)
def load_euroc_cleaned(seq_dir) -> Sequence:
    d = Path(seq_dir)
    pngs = sorted((d / "cam0" / "data").glob("*.png"))
    frame_ts = np.array([int(p.stem) for p in pngs], dtype=np.int64)
    arr = np.load(d / "imu_input_array.npy")      # (F-1, 10, 6): accel xyz, gyro xyz


# ---------------------------------------------------------------- EuRoC (cleaned) -- final definition
def load_euroc_cleaned(seq_dir) -> Sequence:
    d = Path(seq_dir)
    pngs = sorted((d / "cam0" / "data").glob("*.png"))
    frame_ts = np.array([int(p.stem) for p in pngs], dtype=np.int64)
    arr = np.load(d / "imu_input_array.npy")      # (F-1, 10, 6): accel xyz, gyro xyz per camera interval
    gt = np.load(d / "gt_array.npy")              # (F-1, 3) positions
    F = len(frame_ts)
    assert arr.shape[0] == F - 1 and gt.shape[0] == F - 1, (d.name, F, arr.shape, gt.shape)
    k = arr.shape[1]
    frac = np.arange(1, k + 1) / k                # samples evenly spaced; last one lands on the next frame time
    t = (frame_ts[:-1, None] + np.diff(frame_ts)[:, None] * frac[None, :]).round().astype(np.int64)
    flat = arr.reshape(-1, 6)
    return Sequence(
        name=d.name, frame_ts=frame_ts, frame_paths=pngs,
        imu=Imu(t.reshape(-1), flat[:, 0:3].copy(), flat[:, 3:6].copy()),
        gt_t_ns=frame_ts[1:], gt_p=gt.copy(), gt_q=None,
        meta=dict(dataset="euroc_cleaned", imu_hz=200, cam_hz=20,
                  note="IMU timestamps synthesized (even spacing); GT is position only"))


# ---------------------------------------------------------------- calibration / undistortion
def parse_kitti_calib(calib_cam_to_cam, cam="02"):
    """Raw (unrectified) intrinsics for one camera from calib_cam_to_cam.txt."""
    kv = {}
    for line in open(calib_cam_to_cam):
        if ":" in line:
            k, v = line.split(":", 1)
            try:
                kv[k.strip()] = np.array(v.split(), dtype=float)
            except ValueError:
                pass                                  # e.g. the calib_time line
    K = kv[f"K_{cam}"].reshape(3, 3)
    D = kv[f"D_{cam}"]                                # k1 k2 p1 p2 k3 (OpenCV order)
    W, H = (int(x) for x in kv[f"S_{cam}"])
    return K, D, (W, H)


class Undistorter:
    """Removes lens distortion but keeps the original K, so the rest of the pipeline uses one matrix."""
    def __init__(self, K, D, size_wh):
        self.K, self.D, self.size = K, D, size_wh
        self.m1, self.m2 = cv2.initUndistortRectifyMap(K, D, None, K, size_wh, cv2.CV_32FC1)

    def __call__(self, img):
        assert img.shape[1] == self.size[0] and img.shape[0] == self.size[1], \
            f"image {img.shape[::-1]} != calibrated size {self.size}"
        return cv2.remap(img, self.m1, self.m2, cv2.INTER_LINEAR)
