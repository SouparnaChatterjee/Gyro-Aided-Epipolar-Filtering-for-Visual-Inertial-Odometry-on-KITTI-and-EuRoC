
import numpy as np
from scipy.spatial.transform import Rotation as Rot
from .eskf import ESKF
from .inertial import exp_so3, skew

IX = np.r_[0:3, 6:9]                  # theta and p inside the 15-dim nav error state
CHI2_99 = {3: 11.34, 5: 15.09}


def log_so3(R):
    return Rot.from_matrix(R).as_rotvec()


class VIOFilter(ESKF):
    # ESKF plus one stochastic clone (rotation, position) of the pose at the previous camera time.
    # Joint error state: [nav 15 | clone theta 3 | clone p 3] = 21
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.clone = None
        self.Cc = None                # (15, 6) nav x clone cross-covariance
        self.Pcc = None               # (6, 6)

    def augment(self):
        self.clone = (self.R.copy(), self.p.copy())
        self.Cc = self.P[:, IX].copy()
        self.Pcc = self.P[np.ix_(IX, IX)].copy()

    def propagate(self, *args, **kw):
        super().propagate(*args, **kw)
        if self.clone is not None:
            self.Cc = self._F @ self.Cc

    def update_relpose(self, R_vo, t_vo, R_cb, sig_rot, sig_dir, min_disp=0.05, use_dir=True):
        # R_vo, t_vo: previous camera -> current camera (OpenCV recoverPose convention), |t_vo| = 1
        if self.clone is None:
            return dict(status="noclone")
        Rc, pc = self.clone
        A = self.R.T @ Rc
        R_pred = R_cb @ A @ R_cb.T
        zs, Hs, rs = [log_so3(R_vo @ R_pred.T)], [], [sig_rot ** 2] * 3
        Hr = np.zeros((3, 21)); Hr[:, 0:3] = -R_cb; Hr[:, 15:18] = R_cb @ A
        Hs.append(Hr)
        dp = self.p - pc
        nrm = float(np.linalg.norm(dp))
        used_dir = bool(use_dir and nrm >= min_disp)
        if used_dir:
            d = Rc.T @ dp
            uh = (R_cb @ d) / nrm
            c = -R_vo.T @ np.asarray(t_vo).ravel(); c = c / np.linalg.norm(c)
            a = np.array([1.0, 0, 0]) if abs(c[0]) < 0.9 else np.array([0, 1.0, 0])
            b1 = np.cross(c, a); b1 /= np.linalg.norm(b1)
            B = np.stack([b1, np.cross(c, b1)], axis=1)               # basis of the plane normal to the measured direction
            J = B.T @ (np.eye(3) - np.outer(uh, uh)) / nrm
            M = J @ (R_cb @ Rc.T)
            Hd = np.zeros((2, 21)); Hd[:, 6:9] = M; Hd[:, 18:21] = -M; Hd[:, 15:18] = J @ (R_cb @ skew(d))
            zs.append(-B.T @ uh); Hs.append(Hd); rs += [sig_dir ** 2] * 2
        z, H, Rm = np.concatenate(zs), np.vstack(Hs), np.diag(rs)
        Pj = np.block([[self.P, self.Cc], [self.Cc.T, self.Pcc]])
        S = H @ Pj @ H.T + Rm
        nis = float(z @ np.linalg.solve(S, z))
        info = dict(status="ok", nis=nis, dof=len(z), used_dir=used_dir,
                    rot_deg=float(np.degrees(np.linalg.norm(z[:3]))), disp=nrm)
        if nis > CHI2_99[len(z)]:
            info["status"] = "gated"
            return info
        K = Pj @ H.T @ np.linalg.inv(S)
        dx = K @ z
        IKH = np.eye(21) - K @ H
        Pj = IKH @ Pj @ IKH.T + K @ Rm @ K.T
        Pj = 0.5 * (Pj + Pj.T)
        self.P, self.Cc, self.Pcc = Pj[:15, :15], Pj[:15, 15:], Pj[15:, 15:]
        self.R = self.R @ exp_so3(dx[0:3]); self.v = self.v + dx[3:6]; self.p = self.p + dx[6:9]
        self.bg = self.bg + dx[9:12]; self.ba = self.ba + dx[12:15]
        return info
