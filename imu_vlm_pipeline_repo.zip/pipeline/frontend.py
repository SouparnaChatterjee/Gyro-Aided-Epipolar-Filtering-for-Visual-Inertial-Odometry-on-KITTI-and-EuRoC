import time
import numpy as np, cv2

LK_CRIT = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01)


class Tracker:
    """KLT feature tracker: forward-backward check, RANSAC on the fundamental matrix, border mask."""
    def __init__(self, max_feats=300, min_dist=20, border=20, win=21, levels=3,
                 fb_thresh=1.0, ransac_px=1.0, quality=0.01, refill_below=0.8):
        self.max_feats, self.min_dist, self.border = max_feats, min_dist, border
        self.win, self.levels, self.fb_thresh = win, levels, fb_thresh
        self.ransac_px, self.quality, self.refill_below = ransac_px, quality, refill_below
        self.prev = None
        self.pts = np.empty((0, 1, 2), np.float32)
        self.ids = np.empty(0, np.int64)
        self.age = np.empty(0, np.int64)
        self.next_id = 0
        self.dead_lengths = []
        self._mask = None

    def _border_mask(self, shape):
        if self._mask is None or self._mask.shape != shape:
            m = np.zeros(shape, np.uint8)
            b = self.border
            m[b:shape[0] - b, b:shape[1] - b] = 255
            self._mask = m
        return self._mask

    def _inside(self, pts, shape):
        x, y, b = pts[:, 0, 0], pts[:, 0, 1], self.border
        return (x >= b) & (x < shape[1] - b) & (y >= b) & (y < shape[0] - b)

    def step(self, gray):
        T, info = {}, dict(n_prev=len(self.pts), n_klt=0, n_inl=0, n_new=0)
        p_prev = p_cur = np.empty((0, 2), np.float32)
        if self.prev is not None and len(self.pts):
            t0 = time.perf_counter()
            kw = dict(winSize=(self.win, self.win), maxLevel=self.levels, criteria=LK_CRIT)
            nxt, st, _ = cv2.calcOpticalFlowPyrLK(self.prev, gray, self.pts, None, **kw)
            back, st2, _ = cv2.calcOpticalFlowPyrLK(gray, self.prev, nxt, None, **kw)
            T["klt"] = time.perf_counter() - t0
            fb = np.linalg.norm(back - self.pts, axis=2).ravel()
            s_ok = (st.ravel() == 1) & (st2.ravel() == 1)
            f_ok = fb < self.fb_thresh
            b_ok = self._inside(nxt, gray.shape)
            ok = s_ok & f_ok & b_ok
            self._dbg = dict(pts=self.pts[:, 0, :].copy(), age=self.age.copy(), s=s_ok, f=f_ok, b=b_ok)
            info["d_status"] = int((~s_ok).sum())
            info["d_fb"] = int((s_ok & ~f_ok).sum())
            info["d_border"] = int((s_ok & f_ok & ~b_ok).sum())
            info["n_klt"] = int(ok.sum())

            t0 = time.perf_counter()
            if ok.sum() >= 15:
                _, inl = cv2.findFundamentalMat(self.pts[ok], nxt[ok], cv2.FM_RANSAC, self.ransac_px, 0.99)
                if inl is not None:
                    keep = np.zeros_like(ok)
                    keep[np.where(ok)[0][inl.ravel() == 1]] = True
                    ok = keep
            T["ransac"] = time.perf_counter() - t0
            info["d_ransac"] = info["n_klt"] - int(ok.sum())
            self._dbg["final"] = ok.copy()
            info["n_inl"] = int(ok.sum())

            self.dead_lengths += self.age[~ok].tolist()
            p_prev = self.pts[ok][:, 0, :].copy()
            self.pts, self.ids, self.age = nxt[ok], self.ids[ok], self.age[ok] + 1
            p_cur = self.pts[:, 0, :].copy()

        t0 = time.perf_counter()
        need = self.max_feats - len(self.pts)
        if self.prev is None or need > (1 - self.refill_below) * self.max_feats:
            m = self._border_mask(gray.shape).copy()
            for x, y in self.pts[:, 0, :]:
                cv2.circle(m, (int(x), int(y)), self.min_dist, 0, -1)
            new = cv2.goodFeaturesToTrack(gray, need, self.quality, self.min_dist, mask=m)
            if new is not None:
                n = len(new)
                self.pts = np.concatenate([self.pts, new.astype(np.float32)])
                self.ids = np.concatenate([self.ids, np.arange(self.next_id, self.next_id + n)])
                self.age = np.concatenate([self.age, np.ones(n, np.int64)])
                self.next_id += n
                info["n_new"] = n
        T["detect"] = time.perf_counter() - t0
        self.prev = gray
        info["n_total"] = len(self.pts)
        return T, info, (p_prev, p_cur)

    def track_lengths(self):
        return np.array(self.dead_lengths + self.age.tolist())
