import numpy as np


def interp_pos(t_est, p_est, t_q):
    return np.stack([np.interp(t_q, t_est, p_est[:, i]) for i in range(3)], axis=1)


def align_yaw_trans(p_est, p_gt):
    """Best-fit yaw + translation (4-DoF). Gravity makes roll/pitch observable, so they stay fixed."""
    me, mg = p_est.mean(0), p_gt.mean(0)
    e, g = p_est - me, p_gt - mg
    th = np.arctan2((e[:, 0] * g[:, 1] - e[:, 1] * g[:, 0]).sum(),
                    (e[:, 0] * g[:, 0] + e[:, 1] * g[:, 1]).sum())
    c, s = np.cos(th), np.sin(th)
    Rz = np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])
    return e @ Rz.T + mg


def rmse(a, b):
    return float(np.sqrt(np.mean(np.sum((a - b) ** 2, axis=1))))


def ate(p_est, p_gt):
    return rmse(align_yaw_trans(p_est, p_gt), p_gt)


def windowed_ate(t_ns, p_est, p_gt, win_s=5.0, min_pts=5):
    """ATE inside consecutive non-overlapping windows, each aligned on its own -> local drift rate."""
    ts = (t_ns - t_ns[0]) * 1e-9
    out = []
    for k in range(int(ts[-1] // win_s)):
        m = (ts >= k * win_s) & (ts < (k + 1) * win_s)
        if m.sum() >= min_pts:
            out.append((k * win_s, ate(p_est[m], p_gt[m])))
    return np.array(out)        # columns: window start (s), ATE (m)
