import numpy as np
from scipy.spatial.transform import Rotation as Rot

G_W = np.array([0.0, 0.0, 9.81])        # gravity in the world frame (z up)


def skew(w):
    return np.array([[0, -w[2], w[1]], [w[2], 0, -w[0]], [-w[1], w[0], 0]])


def exp_so3(w):
    th = np.linalg.norm(w)
    if th < 1e-9:
        return np.eye(3) + skew(w)
    K = skew(w / th)
    return np.eye(3) + np.sin(th) * K + (1 - np.cos(th)) * (K @ K)


def attitude_from_gravity(acc, n=30):
    """Body->world rotation from the mean accelerometer reading (assumes ~still). Yaw is arbitrary."""
    a = acc[:n].mean(axis=0)
    rot, _ = Rot.align_vectors([[0.0, 0.0, 1.0]], [a / np.linalg.norm(a)])
    return rot


def strapdown(imu, i0, R0, p0, v0):
    """Integrate gyro + accel from sample i0 (no bias estimation, no corrections).
    R0: scipy Rotation, body->world. Returns t_ns, p, v at samples i0..end."""
    t, acc, gyr = imu.t_ns[i0:], imu.acc[i0:], imu.gyr[i0:]
    n = len(t)
    P, V = np.zeros((n, 3)), np.zeros((n, 3))
    R, p, v = R0.as_matrix(), np.array(p0, float), np.array(v0, float)
    P[0], V[0] = p, v
    for k in range(n - 1):
        dt = (t[k + 1] - t[k]) * 1e-9
        w = 0.5 * (gyr[k] + gyr[k + 1])
        a = 0.5 * (acc[k] + acc[k + 1])
        a_w = R @ exp_so3(0.5 * w * dt) @ a - G_W      # mid-interval attitude
        R = R @ exp_so3(w * dt)
        p = p + v * dt + 0.5 * a_w * dt * dt
        v = v + a_w * dt
        P[k + 1], V[k + 1] = p, v
    return t, P, V


def rel_rot(imu, t0, t1):
    """Body rotation between t0 < t1 from the gyro: R_wb(t0)^T R_wb(t1), i.e. body_t1 -> body_t0.
    Integrates exactly between t0 and t1 (gyro interpolated at both ends)."""
    m = (imu.t_ns > t0) & (imu.t_ns < t1)
    ts = np.concatenate([[t0], imu.t_ns[m], [t1]])
    g = np.stack([np.interp(ts, imu.t_ns, imu.gyr[:, i]) for i in range(3)], axis=1)
    R = np.eye(3)
    for k in range(len(ts) - 1):
        dt = (ts[k + 1] - ts[k]) * 1e-9
        R = R @ exp_so3(0.5 * (g[k] + g[k + 1]) * dt)
    return R
