import numpy as np
from .inertial import exp_so3, skew, G_W


class ESKF:
    """Error-state EKF core. Nominal state: R (body->world), v, p, bg, ba.
    Error state (15): [dtheta, dv, dp, dbg, dba], attitude error in the local frame: R = R_hat * exp(dtheta)."""
    def __init__(self, R0, v0, p0, bg0=None, ba0=None,
                 sig_g=1.7e-4, sig_a=2e-3, sig_bg=1.9e-5, sig_ba=3e-3, P0=None):
        self.R, self.v, self.p = np.array(R0, float), np.array(v0, float), np.array(p0, float)
        self.bg = np.zeros(3) if bg0 is None else np.array(bg0, float)
        self.ba = np.zeros(3) if ba0 is None else np.array(ba0, float)
        self.sig = (sig_g, sig_a, sig_bg, sig_ba)          # continuous noise densities / random walks
        self.P = (np.diag([1e-4] * 3 + [1e-2] * 3 + [1e-4] * 3 + [1e-6] * 3 + [1e-4] * 3)
                  if P0 is None else np.array(P0, float))

    def propagate(self, acc0, gyr0, acc1, gyr1, dt):
        sg, sa, sbg, sba = self.sig
        w = 0.5 * (gyr0 + gyr1) - self.bg
        a = 0.5 * (acc0 + acc1) - self.ba
        R = self.R
        a_w = (R @ exp_so3(0.5 * w * dt)) @ a - G_W

        F = np.eye(15)
        F[0:3, 0:3] -= skew(w) * dt
        F[0:3, 9:12] = -np.eye(3) * dt
        F[3:6, 0:3] = -R @ skew(a) * dt
        F[3:6, 12:15] = -R * dt
        F[6:9, 3:6] = np.eye(3) * dt
        Q = np.zeros((15, 15))
        Q[0:3, 0:3] = np.eye(3) * sg ** 2 * dt
        Q[3:6, 3:6] = np.eye(3) * sa ** 2 * dt
        Q[9:12, 9:12] = np.eye(3) * sbg ** 2 * dt
        Q[12:15, 12:15] = np.eye(3) * sba ** 2 * dt
        self._F = F
        self.P = F @ self.P @ F.T + Q

        self.p = self.p + self.v * dt + 0.5 * a_w * dt * dt
        self.v = self.v + a_w * dt
        self.R = R @ exp_so3(w * dt)
