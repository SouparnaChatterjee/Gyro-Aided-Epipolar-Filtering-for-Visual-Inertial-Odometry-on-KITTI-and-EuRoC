_All numbers are generated from `results.json`. CPU: Intel(R) Xeon(R) CPU @ 2.00GHz._

### EuRoC (cleaned, 188x120), first 70 s: ATE in metres, 4-DoF aligned

Stay still = ATE of an estimate that never moves. The inflate / sigma 0.3 default was chosen after all five sequences had been seen, so there is no held-out set. The full grid is the next table.

| sequence | stay still | IMU only | VIO, hard gate | VIO, inflate (default) | beats stay-still? |
|---|---|---|---|---|---|
| V1_01_easy | 1.85 | 76.7 | 0.27 | 0.28 | yes, 6.7x better |
| V1_02_medium | 1.84 | 516.0 | 1359.39 | 1480.49 | no |
| V1_03_difficult | 1.74 | 255.1 | 2.41 | 2.42 | no |
| V2_01_easy | 2.06 | 475.0 | 0.44 | 0.80 | yes, 2.6x better |
| V2_02_medium | 2.09 | 475.7 | 0.75 | 0.74 | yes, 2.8x better |

### EuRoC, every setting tried: ATE in metres

| sequence | direction sigma (rad) | hard gate | inflate | no gate |
|---|---|---|---|---|
| V1_01_easy | 0.1 | 0.93 | 0.42 | 0.36 |
| V1_01_easy | 0.15 | 0.42 | 0.41 | 0.33 |
| V1_01_easy | 0.3 | 0.27 | 0.28 | 0.28 |
| V1_01_easy | 0.5 | 0.20 | 0.20 | 0.20 |
| V1_02_medium | 0.1 | 986.74 | 1526.93 | 5.92 |
| V1_02_medium | 0.15 | 2.21 | 1599.58 | 2037.31 |
| V1_02_medium | 0.3 | 1359.39 | 1480.49 | 1489.11 |
| V1_02_medium | 0.5 | 1133.48 | 1133.48 | 1133.48 |
| V1_03_difficult | 0.1 | 666.00 | 2.15 | 2.64 |
| V1_03_difficult | 0.15 | 534.74 | 2.33 | 2.42 |
| V1_03_difficult | 0.3 | 2.41 | 2.42 | 2.42 |
| V1_03_difficult | 0.5 | 23.13 | 23.13 | 23.13 |
| V2_01_easy | 0.1 | 0.46 | 1.04 | 1.43 |
| V2_01_easy | 0.15 | 6.85 | 1.07 | 1.44 |
| V2_01_easy | 0.3 | 0.44 | 0.80 | 0.81 |
| V2_01_easy | 0.5 | 0.39 | 0.39 | 0.39 |
| V2_02_medium | 0.1 | 0.60 | 0.76 | 0.81 |
| V2_02_medium | 0.15 | 0.66 | 0.81 | 0.85 |
| V2_02_medium | 0.3 | 0.75 | 0.74 | 0.73 |
| V2_02_medium | 0.5 | 0.71 | 0.71 | 0.71 |

### KITTI raw, exact start: end error / RMSE in metres (unaligned)

All six configurations shown, nothing selected. Ground-truth initial pose and velocity (the x0.6 start corrupts the velocity).

| config | 0005 | 0001 | 0011 | 0014 | 0019 |
|---|---|---|---|---|---|
| IMU only (reference) | 2.9 / 1.8 | 0.5 / 0.3 | 2.2 / 1.3 | 12.7 / 7.4 | 17.8 / 8.1 |
| prior .01, dir .05 (current) | 5.1 / 2.3 | 0.4 / 0.3 | 3.0 / 1.0 | 68.4 / 29.0 | 11.8 / 5.5 |
| prior .003, dir .05 | 5.3 / 2.2 | 0.5 / 0.4 | 2.4 / 0.9 | 39.7 / 15.7 | 7.4 / 4.6 |
| prior .001, dir .05 | 5.5 / 2.0 | 0.5 / 0.4 | 1.9 / 0.9 | 38.8 / 15.1 | 5.3 / 4.3 |
| prior .001, dir .2 | 5.0 / 1.9 | 0.4 / 0.3 | 1.0 / 0.6 | 6.3 / 3.0 | 4.7 / 3.7 |
| prior .01, dir .5 (stopgap) | 4.2 / 1.7 | 0.4 / 0.3 | 0.9 / 0.5 | 4.3 / 3.3 | 5.7 / 3.7 |

### KITTI raw, v0 x0.6, sigma_v0 1.5: end error / RMSE in metres (unaligned)

All six configurations shown, nothing selected. Ground-truth initial pose and velocity (the x0.6 start corrupts the velocity).

| config | 0005 | 0001 | 0011 | 0014 | 0019 |
|---|---|---|---|---|---|
| IMU only (reference) | 21.9 / 12.7 | 62.2 / 35.9 | 119.2 / 68.4 | 120.0 / 69.2 | 294.6 / 168.7 |
| prior .01, dir .05 (current) | 2.1 / 1.5 | 29.0 / 23.1 | 84.1 / 46.6 | 76.2 / 32.2 | 30.6 / 33.2 |
| prior .003, dir .05 | 3.7 / 1.6 | 21.1 / 16.6 | 24.7 / 18.0 | 48.8 / 20.2 | 28.0 / 30.3 |
| prior .001, dir .05 | 5.0 / 1.8 | 16.9 / 14.2 | 17.6 / 13.9 | 46.7 / 19.1 | 24.7 / 26.5 |
| prior .001, dir .2 | 4.7 / 1.7 | 42.7 / 28.6 | 74.3 / 43.0 | 19.2 / 8.1 | 69.0 / 58.4 |
| prior .01, dir .5 (stopgap) | 2.5 / 2.1 | 58.2 / 34.1 | 103.5 / 59.7 | 18.3 / 9.2 | 106.9 / 88.3 |

### KITTI zero-velocity update (sigma_v 0.2 m/s): end error / RMSE in metres

Detector thresholds taken from the single stop in KITTI drive 0011; no validation set. Drive 0011 has the only clear stop; on 0019 the detector fired during a slow roll (GT up to 0.38 m/s).

| drive | start | config | no ZUPT | ZUPT |
|---|---|---|---|---|
| 0011 | exact | IMU only | 2.2 / 1.3 | 0.3 / 0.8 |
| 0011 | exact | VIO | 3.0 / 1.0 | 0.2 / 0.8 |
| 0011 | v0x0.6 | IMU only | 119.2 / 68.4 | 10.8 / 41.5 |
| 0011 | v0x0.6 | VIO | 84.1 / 46.6 | 13.2 / 30.3 |
| 0019 | exact | IMU only | 17.8 / 8.1 | 2.4 / 6.1 |
| 0019 | exact | VIO | 11.8 / 5.5 | 15.8 / 7.2 |
| 0019 | v0x0.6 | IMU only | 294.6 / 168.7 | 74.2 / 144.2 |
| 0019 | v0x0.6 | VIO | 30.6 / 33.2 | 39.6 / 34.4 |

### Per-stage latency (ms unless stated)

One run on a shared 4-vCPU CPU; run-to-run variation is about 15%. The KITTI row excludes the essential-matrix solve and the filter update.

| pipeline | stage | p50 | p99 |
|---|---|---|---|
| KITTI 1392x512 | undistort | 1.28 | 1.95 |
| KITTI 1392x512 | klt | 12.85 | 20.18 |
| KITTI 1392x512 | ransac | 0.64 | 1.36 |
| KITTI 1392x512 | detect | 11.69 | 14.31 |
| KITTI 1392x512 | tracker total | 25.46 | 34.21 |
| EuRoC 188x120 | klt | 1.53 | 2.10 |
| EuRoC 188x120 | ransac | 0.18 | 0.33 |
| EuRoC 188x120 | detect | 1.46 | 1.72 |
| EuRoC 188x120 | tracker total | 3.13 | 3.81 |
| EuRoC 188x120 | epipolar_direction | 0.58 | 0.97 |
| ESKF propagate per IMU sample | per IMU sample, in microseconds | 158.7 | 287.9 |

### IMU-only dead reckoning, full sequences, ATE in metres

Different window from the 70 s EuRoC table above (full length here), so the two tables cannot be compared directly.

| sequence | ATE, zero bias | 5 s-window median | ATE, static gyro bias | 5 s-window median |
|---|---|---|---|---|
| 2011_09_26_drive_0005_extract | 0.9 | 0.2 | n/a (not computed) | n/a |
| V1_01_easy | 23527.3 | 789.8 | 808.0 | 15.9 |
| V1_02_medium | 8669.4 | 466.6 | 793.8 | 42.6 |
| V1_03_difficult | 16346.6 | 743.7 | 705.7 | 27.7 |
| V2_01_easy | 9968.9 | 334.1 | 1491.9 | 50.6 |
| V2_02_medium | 12278.0 | 404.5 | 1889.4 | 65.9 |
